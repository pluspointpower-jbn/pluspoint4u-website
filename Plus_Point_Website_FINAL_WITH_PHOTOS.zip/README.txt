PLUS POINT GROUP OF EDUCATION — UPDATED WEBSITE

This is a standalone index.html with the five real school photos embedded directly in the file. No images folder is needed.

To publish: upload index.html to the root of the GitHub Pages repository and replace the existing index.html, then commit to main. Keep the existing CNAME file unchanged.

WhatsApp: 9813436340
Other contact: 9588399388
Facebook page: PlusPoint
